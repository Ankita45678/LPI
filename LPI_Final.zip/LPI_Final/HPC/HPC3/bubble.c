#include <omp.h>
#include <stdio.h>
#include <stdlib.h>


void swap();

int main (int argc, char *argv[]) {
	int SIZE =1<<8;
	int A[SIZE];
	int k=0;
	for(k=0;k<SIZE;k++)
	{
	    A[k]=rand()%SIZE;
	}
	//int A[5] = {6,9,1,3,7};
	int N = SIZE;
	int i=0, j=0; 
	int first;
	double start,end;
	start=omp_get_wtime();
	for( i = 0; i < N-1; i++ )
	{
		first = i % 2; 
		#pragma omp parallel for default(none),shared(A,first,N)
		for( j = first; j < N-1; j += 1 )
		{
			if( A[ j ] > A[ j+1 ] )
			{
				swap( &A[ j ], &A[ j+1 ] );
			}
		}
	}
end=omp_get_wtime();
	for(i=0;i<N;i++)
	{
		printf(" %d",A[i]);
	}

printf("\n-------------------------\n Time Parallel= %f",(end-start));
}

void swap(int *num1, int *num2)
{

	int temp = *num1;
	*num1 =  *num2;
	*num2 = temp;
}

/*
[BE@localhost 4243]$ gcc -fopenmp bubble.c -o bubble
[BE@localhost 4243]$ time ./bubble
 0 1 2 4 5 5 5 5 9 11 11 13 14 15 16 17 17 19 20 21 21 23 24 25 26 26 26 27 27 27 28 28 30 31 33 33 34 35 35 36 37 41 41 41 42 43 46 49 50 50 50 50 51 51 52 54 56 56 58 58 59 59 59 59 60 60 61 61 62 62 65 65 67 70 71 71 72 72 73 74 75 77 78 78 78 79 80 81 84 84 84 85 88 88 90 90 90 92 92 92 92 92 93 94 94 95 97 99 99 100 100 100 102 103 103 105 107 108 111 112 112 112 115 115 115 116 117 118 119 121 121 123 124 124 125 126 127 130 130 134 135 137 141 143 148 148 149 150 151 152 153 154 155 155 158 158 159 161 161 162 163 164 168 168 169 170 170 170 171 171 172 172 175 175 175 176 177 178 179 179 180 181 181 183 186 186 187 187 188 189 190 190 194 197 197 198 198 201 202 202 203 203 205 205 205 208 209 211 212 212 216 219 220 220 220 224 225 225 226 227 227 228 229 230 231 232 232 233 233 233 234 235 236 236 236 239 240 241 242 242 245 247 248 248 248 249 250 250 251 251 251 251 252 253 254 255
-------------------------
 Time Parallel= 0.003057
real	0m0.004s
user	0m0.009s
sys	0m0.000s

*/


