#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "omp.h"

#define MAX_SIZE 1<<8

//Function for creating an input array||Update accoorind to your need
void generate_list(int * x, int n) {
   int i,j,t;
   for (i = 0; i < n; i++)
     x[i] = i;
   for (i = 0; i < n; i++) {
     j = rand() % n;
     t = x[i];
     x[i] = x[j];
     x[j] = t;
   }
}

void print_list(int * x, int n) {
   int i;
   for (i = 0; i < n; i++) {
      printf("%d ",x[i]);
   }
}

//Merging 2 sorted subarrays into one tmp array
void merge(int * X, int n, int * tmp) {
   int i = 0;
   int j = n/2;
   int ti = 0;
	//i will iterate till first  half anf J will iterate for 2nd half of array
   while (i<n/2 && j<n) {
      if (X[i] < X[j]) {
         tmp[ti] = X[i];
         ti++; i++;
      } else {
         tmp[ti] = X[j];
         ti++; 
	 j++;
      }
   }
   while (i<n/2) { /* finish up lower half */
      tmp[ti] = X[i];
	ti++;
	i++;
   }
      while (j<n) { /* finish up upper half */
         tmp[ti] = X[j];
         ti++; 
	 j++;
   }
	//Copy sorted array tmp back to  X (Original array)
   memcpy(X, tmp, n*sizeof(int));

} // end of merge()

void mergesort(int * X, int n, int * tmp)
{
   if (n < 2) return;

   #pragma omp task firstprivate (X, n, tmp)
   mergesort(X, n/2, tmp);

   #pragma omp task firstprivate (X, n, tmp)
   mergesort(X+(n/2), n-(n/2), tmp);
	
   //Wait for both paralel tasks to complete execution
   #pragma omp taskwait

    /* merge sorted halves into sorted list */
   merge(X, n, tmp);
}


int main()
{
   int n = 1<<8;
   double start, stop;

   int data[MAX_SIZE], tmp[MAX_SIZE];

   generate_list(data, n);
   printf("List Before Sorting...\n");
   print_list(data, n);
   start = omp_get_wtime();
   #pragma omp parallel
   {
      #pragma omp single
      mergesort(data, n, tmp);
   }
   stop = omp_get_wtime();
   printf("\nList After Sorting...\n");
   print_list(data, n);
   printf("\nTime: %g\n",stop-start);
}


/*
[BE@localhost 4243]$ gcc -fopenmp merge.c -o merge
[BE@localhost 4243]$ ./merge
List Before Sorting...
131 73 96 115 237 223 74 236 41 166 186 192 242 34 56 122 173 164 84 138 152 167 231 43 8 184 63 136 195 159 146 144 102 226 10 52 38 40 163 25 88 199 83 36 37 233 94 212 11 178 64 85 215 180 240 194 210 130 134 82 109 214 72 135 112 68 220 20 45 225 252 181 53 104 126 157 234 213 98 200 127 227 92 255 91 78 65 13 9 175 31 7 238 118 156 217 105 3 254 29 162 250 170 116 100 93 209 230 222 39 16 185 132 216 190 125 137 249 95 26 168 169 70 123 177 114 241 196 108 239 15 103 59 67 193 229 202 171 203 208 66 0 87 189 154 183 201 120 6 149 142 197 139 46 50 80 219 151 57 161 86 117 22 49 30 153 205 77 32 5 228 12 211 124 89 243 1 33 14 48 140 76 232 24 119 148 188 90 113 75 207 245 58 69 97 111 179 145 19 2 28 55 110 221 23 147 107 21 27 44 4 129 158 62 61 155 251 54 206 187 101 248 42 128 99 71 244 141 246 17 176 79 235 133 204 121 174 81 35 224 191 51 143 160 60 18 172 165 150 106 182 198 253 247 218 47 
List After Sorting...
0 1 4 4 5 6 7 8 9 10 11 12 13 13 14 15 20 21 22 23 24 25 27 27 28 30 31 32 33 34 36 37 38 40 41 42 42 43 44 45 46 47 48 49 50 52 53 54 54 55 56 57 58 59 61 62 63 64 65 65 66 67 68 69 70 72 73 74 75 76 77 78 80 82 83 84 85 86 87 88 89 90 91 92 94 96 97 98 101 101 102 103 104 106 107 108 109 110 111 112 113 115 117 119 120 122 123 60 124 126 127 128 128 129 130 131 134 135 136 138 139 140 142 143 144 145 146 147 148 149 150 151 152 153 154 155 157 158 159 160 161 163 164 165 166 167 171 172 173 175 178 179 180 181 182 183 184 186 187 187 188 189 191 192 193 194 195 197 198 199 200 201 202 203 205 206 206 125 132 137 168 169 177 190 196 207 208 209 210 211 212 213 214 215 216 217 218 219 220 221 223 225 226 227 228 229 230 71 79 81 99 121 133 141 174 176 204 224 231 232 233 234 235 236 237 238 239 240 241 242 243 244 245 246 247 248 249 251 251 29 39 93 100 105 116 162 170 185 209 222 230 250 252 253 254 255 
Time: 0.0037304

*/


