import pandas as pd
import numpy as np
import math
%matplotlib inline

import matplotlib.pyplot as plt
import seaborn as sns

dat=pd.read_csv('Iris.csv')

dat.shape

dat[0:10]

list (dat.columns)

dat.describe()

dat['class'].describe()

dat.info()

dat.x1.value_counts()

dat.x1.describe()

dat.x1.min()

dat.x1.max()

sum=dat.x1.sum()
count=dat.x1.count()
mean=sum/count
mean
dat.x1.mean()


sd=0
for value in dat.x1 :
    sd +=(float(value)-mean)**2
sd =math.sqrt(sd/(count-1))
sd

range = dat.x1.max()-dat.x1.min()
range

variance = sd*sd

dat.x1.quantile(0.1)

plt.hist(dat['x1'],bins=30)
plt.xlabel('Dimensions')
plt.ylabel('No of times')
plt.show()

dat.plot(kind='box',subplots=False)

sns.boxplot(y=dat['x1'])

sns.boxplot(data=dat.ix[:,0:4])

dat.loc[:,x1].std()

dat.loc[:,x1].var()

dat.std()

