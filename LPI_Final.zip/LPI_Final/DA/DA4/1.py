import numpy as np
import pandas as pd
import random as rnd
from sklearn import model_selection
from pandas.plotting import scatter_matrix
from sklearn.preprocessing import LabelEncoder
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
from sklearn.naive_bayes import GaussianNB

df=pd.read_csv('store.csv')

df[0:10]

print(df.columns)

df.describe()

df=df.drop(['Start date','End date','Start station','End station','Bike number'],axis=1)

df.head()
le=LabelEncoder()
le.fit(df['Member type'])
df['Member type']=le.transform(df['Member type'])

array=df.values
x_train=array[0:80000,0:3]
y_train=array[0:80000,3]

x_test=array[80000:,0:3]
y_test=array[80000:,3]

from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier()
clf = clf.fit(x_train,y_train)

y_pred = clf.predict(x_test)

acc=round(clf.score(x_test,y_test)*100,2)

acc
