import pandas as pd
import numpy as np
import random as rnd
from sklearn import model_selection

from pandas.tools.plotting import scatter_matrix
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline

from sklearn.naive_bayes import GaussianNB

df=pd.read_csv('Pima.csv')

print(df.info())
print('-'*40)
print(df.info())

df.info()

df.describe()

array=df.values
x_train=array[0:667,0:8]
y_train=array[0:667,8]
x_test=array[667:767,0:8]
y_test=array[667:767,8]

from sklearn.naive_bayes import GaussianNB

clf=GaussianNB()
clf.fit(x_train,y_train)

predicted=clf.predict(x_test)

predicted

acc=round(clf.score(x_test,y_test)*100,2)
acc
